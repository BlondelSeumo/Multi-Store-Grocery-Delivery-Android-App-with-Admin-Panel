package com.tecmanic.gogrocer.modelclass;

public class TimingModel {
    String timing;

    public String getTiming() {
        return timing;
    }

    public void setTiming(String timing) {
        this.timing = timing;
    }
}
