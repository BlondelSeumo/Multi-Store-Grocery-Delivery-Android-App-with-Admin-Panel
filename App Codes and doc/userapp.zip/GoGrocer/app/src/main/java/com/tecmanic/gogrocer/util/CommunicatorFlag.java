package com.tecmanic.gogrocer.util;

public interface CommunicatorFlag {

    void onClick(String dialCode, int flag);

}
