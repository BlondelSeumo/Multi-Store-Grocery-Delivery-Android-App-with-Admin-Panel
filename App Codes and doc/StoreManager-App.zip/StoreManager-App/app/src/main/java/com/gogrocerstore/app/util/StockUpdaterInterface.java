package com.gogrocerstore.app.util;

public interface StockUpdaterInterface {
    void onStockUpdate(int position);
}
