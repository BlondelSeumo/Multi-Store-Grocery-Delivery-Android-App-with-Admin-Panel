package com.tecmanic.gogrocer.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.tecmanic.gogrocer.R;

public class EmptyCart extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty_cart);
    }
}
