package com.tecmanic.gogrocer.util;

public interface PagerNotifier {
    void onPageNotifier(boolean value,int position);
}
