package com.gogrocerstore.app.Model;

public class GoogleMapDataModel {
    private String id;
    private String map_api_key;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMap_api_key() {
        return map_api_key;
    }

    public void setMap_api_key(String map_api_key) {
        this.map_api_key = map_api_key;
    }
}
