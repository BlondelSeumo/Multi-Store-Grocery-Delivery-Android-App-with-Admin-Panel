package com.tecmanic.gogrocer.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.tecmanic.gogrocer.R;

public class InternetConnection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internet_connection);
    }
}
