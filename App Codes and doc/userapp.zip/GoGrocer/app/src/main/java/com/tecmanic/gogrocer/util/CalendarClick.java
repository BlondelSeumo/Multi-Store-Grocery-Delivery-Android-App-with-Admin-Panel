package com.tecmanic.gogrocer.util;

public interface CalendarClick {

    void onCalenderClick(int position);
}
