package com.tecmanic.gogrocer.modelclass;

public class ComplainModel {

    String reason;
    String resId;

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getResId() {
        return resId;
    }

    public void setResId(String resId) {
        this.resId = resId;
    }
}
