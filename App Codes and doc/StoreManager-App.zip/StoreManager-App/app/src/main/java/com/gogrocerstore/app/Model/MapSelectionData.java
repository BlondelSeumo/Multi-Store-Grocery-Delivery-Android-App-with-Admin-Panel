package com.gogrocerstore.app.Model;


public class MapSelectionData {
    private String map_id;
    private String mapbox;
    private String google_map;

    public String getMap_id() {
        return map_id;
    }

    public void setMap_id(String map_id) {
        this.map_id = map_id;
    }

    public String getMapbox() {
        return mapbox;
    }

    public void setMapbox(String mapbox) {
        this.mapbox = mapbox;
    }

    public String getGoogle_map() {
        return google_map;
    }

    public void setGoogle_map(String google_map) {
        this.google_map = google_map;
    }
}
