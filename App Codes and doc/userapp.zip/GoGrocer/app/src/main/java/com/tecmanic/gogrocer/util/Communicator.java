package com.tecmanic.gogrocer.util;

public interface Communicator {
    void onClick(int position);
}
