package com.gogrocerstore.app.util;

public interface BluetoothClick {
    void onClick(int position);
}
