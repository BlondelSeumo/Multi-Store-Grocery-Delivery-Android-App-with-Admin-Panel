package com.tecmanic.gogrocer.util;

public interface CallToDeliveryBoy {

    void onCallToDeliveryBoy(String number);
}
