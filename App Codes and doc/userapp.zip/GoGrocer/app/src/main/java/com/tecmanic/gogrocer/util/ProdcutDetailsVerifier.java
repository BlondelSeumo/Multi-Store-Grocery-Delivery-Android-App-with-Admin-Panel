package com.tecmanic.gogrocer.util;

public interface ProdcutDetailsVerifier {
    void onProductClick(int position, String ViewType);
}
