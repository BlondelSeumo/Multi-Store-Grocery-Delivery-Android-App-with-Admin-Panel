package com.godeliver.user.Model;

/**
 * Created by Rajesh Dabhi on 29/6/2017.
 */

public class My_order_model {

    String sale_id;
    String user_id;
    String on_date;
    String delivery_time_from;
    String delivery_time_to;
    String status;
    String note;

    String is_paid;
    String total_amount;
    String store_name;
    String total_kg;
    String total_items;
    String socity_id;
    String delivery_address;
    String location_id;
    String delivery_charge;
    String new_store_id;
    String assign_to;
    String payment_method;
    String socityname;
    String house;
    String lat;
    String lng;
    String recivername;
    String recivermobile;
    String userLat;
    String userLong;
    String dbLat;
    String dbuserLong;
    String payment_status;

    public String getPayment_status() {
        return payment_status;
    }

    public void setPayment_status(String payment_status) {
        this.payment_status = payment_status;
    }

    public String getUserLat() {
        return userLat;
    }

    public void setUserLat(String userLat) {
        this.userLat = userLat;
    }

    public String getUserLong() {
        return userLong;
    }

    public void setUserLong(String userLong) {
        this.userLong = userLong;
    }

    public String getDbLat() {
        return dbLat;
    }

    public void setDbLat(String dbLat) {
        this.dbLat = dbLat;
    }

    public String getDbuserLong() {
        return dbuserLong;
    }

    public void setDbuserLong(String dbuserLong) {
        this.dbuserLong = dbuserLong;
    }

    public String getSale_id() {
        return sale_id;
    }

    public void setSale_id(String sale_id) {
        this.sale_id = sale_id;
    }

    public String getStore_name() {
        return store_name;
    }

    public void setStore_name(String store_name) {
        this.store_name = store_name;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getOn_date() {
        return on_date;
    }

    public void setOn_date(String on_date) {
        this.on_date = on_date;
    }

    public String getDelivery_time_from() {
        return delivery_time_from;
    }

    public void setDelivery_time_from(String delivery_time_from) {
        this.delivery_time_from = delivery_time_from;
    }

    public String getDelivery_time_to() {
        return delivery_time_to;
    }

    public void setDelivery_time_to(String delivery_time_to) {
        this.delivery_time_to = delivery_time_to;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getIs_paid() {
        return is_paid;
    }

    public void setIs_paid(String is_paid) {
        this.is_paid = is_paid;
    }

    public String getTotal_amount() {
        return total_amount;
    }

    public void setTotal_amount(String total_amount) {
        this.total_amount = total_amount;
    }

    public String getTotal_kg() {
        return total_kg;
    }

    public void setTotal_kg(String total_kg) {
        this.total_kg = total_kg;
    }

    public String getTotal_items() {
        return total_items;
    }

    public void setTotal_items(String total_items) {
        this.total_items = total_items;
    }

    public String getSocity_id() {
        return socity_id;
    }

    public void setSocity_id(String socity_id) {
        this.socity_id = socity_id;
    }

    public String getDelivery_address() {
        return delivery_address;
    }

    public void setDelivery_address(String delivery_address) {
        this.delivery_address = delivery_address;
    }

    public String getLocation_id() {
        return location_id;
    }

    public void setLocation_id(String location_id) {
        this.location_id = location_id;
    }

    public String getDelivery_charge() {
        return delivery_charge;
    }

    public void setDelivery_charge(String delivery_charge) {
        this.delivery_charge = delivery_charge;
    }

    public String getNew_store_id() {
        return new_store_id;
    }

    public void setNew_store_id(String new_store_id) {
        this.new_store_id = new_store_id;
    }

    public String getAssign_to() {
        return assign_to;
    }

    public void setAssign_to(String assign_to) {
        this.assign_to = assign_to;
    }

    public String getPayment_method() {
        return payment_method;
    }

    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    public String getSocityname() {
        return socityname;
    }

    public void setSocityname(String socityname) {
        this.socityname = socityname;
    }

    public String getHouse() {

        return house;
    }

    public void setHouse(String house) {
        this.house = house;
    }

    public String getRecivername() {
        return recivername;
    }

    public void setRecivername(String recivername) {
        this.recivername = recivername;
    }

    public String getRecivermobile() {
        return recivermobile;
    }

    public void setRecivermobile(String recivermobile) {
        this.recivermobile = recivermobile;
    }
}
