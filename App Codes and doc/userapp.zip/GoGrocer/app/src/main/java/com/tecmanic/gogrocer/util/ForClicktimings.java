package com.tecmanic.gogrocer.util;

public interface ForClicktimings {
    void getTimeSlot(String timeslot);
}
