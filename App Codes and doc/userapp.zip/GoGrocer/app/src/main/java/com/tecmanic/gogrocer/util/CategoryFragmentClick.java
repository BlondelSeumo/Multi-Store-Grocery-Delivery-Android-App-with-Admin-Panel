package com.tecmanic.gogrocer.util;

public interface CategoryFragmentClick {

    void onClick(String catId);
}
