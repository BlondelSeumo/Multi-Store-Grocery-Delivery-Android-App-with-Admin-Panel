package com.gogrocerstore.app.util;

public interface DeliveryBoyListClick {

    void onClick(int position);
}
