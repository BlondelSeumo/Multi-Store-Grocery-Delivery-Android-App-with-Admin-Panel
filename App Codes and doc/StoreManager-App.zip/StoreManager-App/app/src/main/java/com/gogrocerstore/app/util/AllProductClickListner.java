package com.gogrocerstore.app.util;

public interface AllProductClickListner {
    void onClick(int position);
}
